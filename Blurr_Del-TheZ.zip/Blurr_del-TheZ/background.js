chrome.runtime.onInstalled.addListener(function() {
  chrome.storage.sync.set({ removeBlur: true, advancedRemoval: true, customFilters: [] }, function() {
    console.log("Hyper Ultra Remove Blur aktiviert.");
  });
});

// WebRequest-API verwenden (z.B. Anfragen blockieren oder manipulieren)
chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    // Hier können wir die Webanforderungen modifizieren oder blockieren
    console.log("WebRequest wurde abgefangen:", details);
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);
