document.addEventListener('DOMContentLoaded', () => {
    const timerButtons = document.querySelectorAll('.timer-button[data-minutes]');
    const stopButton = document.getElementById('stopTimer');
    const timerDisplay = document.getElementById('timer-display');

    function updateAllTabs() {
        chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, {
                    action: 'updatePreventionState'
                });
            });
        });
    }

    chrome.storage.sync.get(['preventionEndTime'], (data) => {
        if (data.preventionEndTime && data.preventionEndTime > Date.now()) {
            const timeLeft = Math.ceil((data.preventionEndTime - Date.now()) / 60000);
            timerDisplay.textContent = `${timeLeft} minutes left`;
        } else {
            timerDisplay.textContent = 'Active';
            chrome.storage.sync.remove(['preventionEndTime']);
        }
    });

    timerButtons.forEach(button => {
        button.addEventListener('click', () => {
            const minutes = parseInt(button.dataset.minutes);
            const endTime = Date.now() + (minutes * 60 * 1000);
            
            chrome.storage.sync.set({
                preventionEndTime: endTime
            }, () => {
                timerDisplay.textContent = `${minutes} minutes left`;
                updateAllTabs();
            });
        });
    });

    stopButton.addEventListener('click', () => {
        chrome.storage.sync.remove(['preventionEndTime'], () => {
            timerDisplay.textContent = 'Active';
            updateAllTabs();
        });
    });
});
