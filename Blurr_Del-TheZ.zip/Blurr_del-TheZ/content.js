
const TheZPerformance = {

    config: {
        batchSize: 50,
        processingDelay: 100,
        cleanupDelay: 2000,
        performanceThreshold: 30,
        debugMode: true,
        timeOptions: [15, 30, 60]
    },

    state: {
        preventionActive: false,
        preventionEndTime: null,
        isProcessing: false,
        specificElement: null
    },

    blurProperties: {
        standard: [
            'filter', 'backdrop-filter', 'background-filter',
            '-webkit-filter', '-moz-filter', '-o-filter', '-ms-filter',
            'blur', 'gaussian-blur', 'backdrop-blur'
        ],
        advanced: [
            'mask-image', '-webkit-mask-image', 'clip-path',
            '-webkit-backdrop-filter', 'perspective-blur',
            'transform-style', 'backface-visibility'
        ],
        pseudo: ['::before', '::after', ':before', ':after', '::backdrop'],
        additional: ['motion-blur', 'zoom-blur', 'radial-blur']
    },

    stats: {
        elementsProcessed: 0,
        blursRemoved: 0,
        startTime: null,
        fps: 0,
        lastFrameTime: 0,
        preventionTimeLeft: 0
    },
    
    async checkPreventionState() {
        return new Promise(resolve => {
            chrome.storage.sync.get(['preventionEndTime'], (data) => {
                if (data.preventionEndTime && data.preventionEndTime > Date.now()) {
                    this.state.preventionActive = true;
                    this.state.preventionEndTime = data.preventionEndTime;
                } else {
                    this.state.preventionActive = false;
                    this.state.preventionEndTime = null;
                }
                resolve();
            });
        });
    },



    loadingUI: {
        show() {
            const loader = document.createElement('div');
            loader.id = 'thez-performance-loader';
            
            const timeButtons = TheZPerformance.config.timeOptions.map(minutes => `
                <button onclick="TheZPerformance.toggleBlurPrevention(${minutes})"
                        style="
                            background: #64ffda;
                            color: #0a192f;
                            border: none;
                            padding: 5px 10px;
                            border-radius: 4px;
                            margin: 2px;
                            cursor: pointer;
                            font-size: 11px;
                            transition: all 0.3s ease;
                        "
                        onmouseover="this.style.transform='scale(1.1)'"
                        onmouseout="this.style.transform='scale(1)'">
                    ${minutes}min
                </button>
            `).join('');

            const stopButton = `
                <button onclick="TheZPerformance.toggleBlurPrevention(0)"
                        style="
                            background: #ff6b6b;
                            color: white;
                            border: none;
                            padding: 5px 10px;
                            border-radius: 4px;
                            margin: 2px;
                            cursor: pointer;
                            font-size: 11px;
                            transition: all 0.3s ease;
                        "
                        onmouseover="this.style.transform='scale(1.1)'"
                        onmouseout="this.style.transform='scale(1)'">
                    Stop Timer
                </button>
            `;

            loader.innerHTML = `
                <div class="thez-loader-container" style="
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: rgba(10, 25, 47, 0.95);
                    border: 2px solid #64ffda;
                    color: #64ffda;
                    padding: 15px 20px;
                    border-radius: 8px;
                    font-family: Arial, sans-serif;
                    z-index: 2147483647;
                    box-shadow: 0 4px 20px rgba(100, 255, 218, 0.2);
                ">
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <div class="thez-spinner" style="
                                width: 20px;
                                height: 20px;
                                border: 2px solid #64ffda;
                                border-top-color: transparent;
                                border-radius: 50%;
                                animation: thez-spin 1s linear infinite;
                            "></div>
                            <span>TheZ's Performance: Optimizing Page...</span>
                        </div>
                        <div class="thez-stats" style="font-size: 12px;">
                            <div>Elements Processed: <span id="thez-elements-count">0</span></div>
                            <div>Blurs Removed: <span id="thez-blurs-count">0</span></div>
                            <div>FPS: <span id="thez-fps">60</span></div>
                            <div>Prevention Time: <span id="thez-prevention-time">Inactive</span></div>
                        </div>
                        <div class="thez-controls" style="display: flex; gap: 5px; margin-top: 5px; flex-wrap: wrap;">
                            <div>Prevent Blur for: ${timeButtons}</div>
                            <div>${stopButton}</div>
                        </div>
                    </div>
                </div>
                <style>
                    @keyframes thez-spin {
                        to { transform: rotate(360deg); }
                    }
                    @keyframes fadeOut {
                        from { opacity: 1; }
                        to { opacity: 0; }
                    }
                </style>
            `;
            document.body.appendChild(loader);
            this.updateStats();
        },

        updateStats() {
            const updateUI = () => {
                const elementsCount = document.getElementById('thez-elements-count');
                const blursCount = document.getElementById('thez-blurs-count');
                const fpsDisplay = document.getElementById('thez-fps');
                const preventionTime = document.getElementById('thez-prevention-time');
                
                if (elementsCount) elementsCount.textContent = TheZPerformance.stats.elementsProcessed;
                if (blursCount) blursCount.textContent = TheZPerformance.stats.blursRemoved;
                if (fpsDisplay) fpsDisplay.textContent = TheZPerformance.stats.fps;
                if (preventionTime) {
                    preventionTime.textContent = TheZPerformance.state.preventionActive ?
                        `${Math.ceil(TheZPerformance.stats.preventionTimeLeft / 60000)}min left` :
                        'Inactive';
                }
                
                requestAnimationFrame(updateUI);
            };
            updateUI();
        },

        hide() {
            const loader = document.getElementById('thez-performance-loader');
            if (loader) {
                loader.style.animation = 'fadeOut 0.3s ease';
                setTimeout(() => loader.remove(), 300);
            }
        }
    },

    toggleBlurPrevention(minutes, specificElement = null) {
        if (minutes === 0 || this.state.preventionActive) {
            // Deaktiviere Prevention
            this.state.preventionActive = false;
            this.state.preventionEndTime = null;
            this.stats.preventionTimeLeft = 0;
            this.state.specificElement = null;
            
            if (specificElement) {
                this.processElements([specificElement]);
            } else {
                this.processElements([...document.querySelectorAll('*')]);
            }
        } else {
            // Aktiviere Prevention
            this.state.preventionActive = true;
            this.state.preventionEndTime = Date.now() + (minutes * 60 * 1000);
            this.stats.preventionTimeLeft = minutes * 60 * 1000;
            this.state.specificElement = specificElement;
            
            const updateTimeLeft = () => {
                if (!this.state.preventionActive) return;
                
                const now = Date.now();
                this.stats.preventionTimeLeft = Math.max(0, this.state.preventionEndTime - now);
                
                if (this.stats.preventionTimeLeft <= 0) {
                    this.state.preventionActive = false;
                    if (this.state.specificElement) {
                        this.processElements([this.state.specificElement]);
                    } else {
                        this.processElements([...document.querySelectorAll('*')]);
                    }
                } else {
                    setTimeout(updateTimeLeft, 1000);
                }
            };
            
            updateTimeLeft();
        }
    },

    performanceMonitor: {
        measure() {
            const now = performance.now();
            const delta = now - TheZPerformance.stats.lastFrameTime;
            TheZPerformance.stats.fps = Math.round(1000 / delta);
            TheZPerformance.stats.lastFrameTime = now;
            
            return TheZPerformance.stats.fps >= TheZPerformance.config.performanceThreshold;
        }
    },

    async removeBlurFromElement(element) {
        if (this.state.preventionActive && 
            (!this.state.specificElement || element === this.state.specificElement)) {
            return false;
        }
        
        try {
            const style = window.getComputedStyle(element);
            let blursFound = 0;

            const processProperty = (prop) => {
                if (style[prop]?.includes('blur')) {
                    element.style.setProperty(prop, 'none', 'important');
                    blursFound++;
                }
            };

            [...this.blurProperties.standard, 
             ...this.blurProperties.advanced,
             ...this.blurProperties.additional].forEach(processProperty);

            ['background', 'backgroundImage', 'backgroundColor'].forEach(prop => {
                if (style[prop]?.includes('blur')) {
                    element.style[prop] = style[prop].replace(/blur\([^)]+\)/g, 'none');
                    blursFound++;
                }
            });

            element.style.setProperty('animation', 'none', 'important');
            element.style.setProperty('transition', 'none', 'important');
            element.style.setProperty('transform', 'translateZ(0)', 'important');

            this.removePseudoElementBlur(element);

            this.stats.blursRemoved += blursFound;
            this.stats.elementsProcessed++;

            return blursFound > 0;
        } catch (error) {
            console.debug('[TheZ Performance] Element processing error:', error);
            return false;
        }
    },

    removePseudoElementBlur(element) {
        if (this.state.preventionActive && 
            (!this.state.specificElement || element === this.state.specificElement)) {
            return;
        }
        
        const styleId = 'thez-pseudo-styles';
        let styleSheet = document.getElementById(styleId);
        
        if (!styleSheet) {
            styleSheet = document.createElement('style');
            styleSheet.id = styleId;
            document.head.appendChild(styleSheet);
        }

        this.blurProperties.pseudo.forEach(pseudo => {
            styleSheet.sheet.insertRule(`
                ${element.tagName.toLowerCase()}${pseudo} {
                    all: initial !important;
                    filter: none !important;
                    backdrop-filter: none !important;
                    -webkit-backdrop-filter: none !important;
                }
            `, 0);
        });
    },

    async processElements(elements, batchSize = this.config.batchSize) {
        if (this.state.isProcessing) return;
        
        this.state.isProcessing = true;
        const batches = Array.from({ length: Math.ceil(elements.length / batchSize) }, (_, i) =>
            elements.slice(i * batchSize, (i + 1) * batchSize)
        );

        for (const batch of batches) {
            if (!this.performanceMonitor.measure()) {
                await new Promise(resolve => setTimeout(resolve, this.config.processingDelay));
            }
            
            await new Promise(resolve => {
                requestAnimationFrame(async () => {
                    await Promise.all(batch.map(element => this.removeBlurFromElement(element)));
                    resolve();
                });
            });
        }
        
        this.state.isProcessing = false;
    },

    observeChanges() {
        let timeout;
        const observer = new MutationObserver(mutations => {
            clearTimeout(timeout);
            timeout = setTimeout(() => {
                const elements = new Set();
                mutations.forEach(mutation => {
                    if (mutation.target) elements.add(mutation.target);
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === 1) elements.add(node);
                    });
                });
                this.processElements([...elements]);
            }, this.config.processingDelay);
        });

        observer.observe(document, {
            attributes: true,
            childList: true,
            subtree: true,
            attributeFilter: ['style', 'class']
        });
    },

    async init() {
        chrome.storage.sync.get("removeBlur", async (data) => {
            if (data.removeBlur) {
                this.stats.startTime = performance.now();
                await this.checkPreventionState();
                
                if (!this.state.preventionActive) {
                    this.loadingUI.show();
                    await this.processElements([...document.querySelectorAll('*')]);
                    this.observeChanges();

                    setTimeout(() => {
                        if (this.performanceMonitor.measure()) {
                            this.loadingUI.hide();
                        }
                    }, this.config.cleanupDelay);
                }

                window.addEventListener('load', async () => {
                    if (!this.state.preventionActive) {
                        await this.processElements([...document.querySelectorAll('*')]);
                    }
                }, { once: true });
            }
        });
    }
};

TheZPerformance.init();
// Am Ende der content.js hinzufügen
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'startTimer') {
        TheZPerformance.toggleBlurPrevention(message.minutes);
    } else if (message.action === 'stopTimer') {
        TheZPerformance.toggleBlurPrevention(0);
    }
});
